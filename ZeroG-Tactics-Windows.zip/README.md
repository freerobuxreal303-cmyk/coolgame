# 🚀 ZERO-G TACTICS: CHRONO LEGENDS
> **2D Action-Tactical Time-Loop Platformer / Hero Arena**  
> *Clone Armies* (Time-loop recording & replay) × Zero-Gravity Newtonian Physics × *Mobile Legends: Bang Bang* (Hero synergies)

[![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20Web-blue.svg)](#)
[![Status](https://img.shields.io/badge/build-passing-brightgreen.svg)](#)
[![License](https://img.shields.io/badge/license-MIT-purple.svg)](#)
[![Class](https://img.shields.io/badge/Project-Game%20Canvas%20Kelas%2012-orange.svg)](#)

---

## 🎮 What is Zero-G Tactics: Chrono Legends?

**Zero-G Tactics: Chrono Legends** is an innovative 2D tactical action combat game where you command a 5-hero squad across iterative timeline loops. Every round, you pilot a single hero champion in real-time. When that champion dies or the 30-second loop clock expires, time resets to $T=0$. You respawn as a new hero, fighting alongside full-fidelity replays of all your previously recorded runs!

Combat takes place in the zero-gravity **Celestial Sanctuary**, featuring directional RCS thrusters, recoil-based weapon propulsion, gravity-inversion singularity wells, repulsor bounce pads, destructible barriers, and automated defense turrets.

```
+-----------------------------------------------------------------------------------+
|                              CHRONO-LOOP TIMELINE                                 |
+-----------------------------------------------------------------------------------+
| Loop 1: [Tank]      --> Hooks Defender + Deploys Grav-Anchor (Dies at T=18s)      |
| Loop 2: [Mage]      --> Drops Singularity Vortex into Tank's Anchor (T=15s-20s)   |
| Loop 3: [Marksman]  --> Snipes clumped enemies; Recoil drifts behind Tank's Cover  |
| Loop 4: [Assassin]  --> Grapple-swings off Marksman's bullet path to core base    |
| Loop 5: [Support]   --> Chrono-Tethers Loop 1 Tank, preventing his death at T=18s!|
+-----------------------------------------------------------------------------------+
```

---

## 🕹️ Controls Guide

| Input | Action | Description |
| :--- | :--- | :--- |
| **W, A, S, D** / Arrows | **RCS Thrusters** | Directional propulsion in zero gravity |
| **Mouse Cursor** | **Aim Angle** | 360° aiming reticle independent of drift vector |
| **Left Click** / **J** | **Basic Attack** | Primary weapon discharge (generates reverse Newtonian recoil) |
| **Right Click** / **Q** / **K** | **Tactical Skill** | Hero special ability (Hook, Cables, Mines, Stasis, Shield) |
| **E** / **R** / **L** | **Ultimate Ability** | Catastrophic tactical ultimate (Implosion, Lasers, Black Hole) |
| **Shift** (Hold/Toggle) | **Drift Mode** | Disables RCS damping; preserves 100% velocity for kiting |
| **Space** / **G** | **Magnetic Anchor** | Locks boots to platform surface; immune to knockback |

---

## ⚡ 5 MLBB-Inspired Hero Archetypes

### 1. 🛡️ Iron Wall Ares (Tank) — *Inspired by Tigreal & Franco*
- **Role:** Frontline vanguard & hazard displacement (HP: 3,200 | Mass: 180 kg)
- **Passive - Kinetic Anchor:** Anchors onto platforms, rendering him immune to knockbacks and singularity wells.
- **Skill - Grav-Harpoon:** Electromagnetic hook pulling enemies into hazards or pulling Ares to walls.
- **Ultimate - Singularity Bastion:** Frontal barrier absorbing shots, followed by a gravitational implosion sucking and stunning all enemies.

### 2. ⚡ Vectra (Assassin) — *Inspired by Fanny & Gusion*
- **Role:** High-velocity burst & priority execution (HP: 1,650 | Mass: 65 kg)
- **Passive - Relativistic Kinetic Energy:** Damage scales dynamically with current flying speed ($v$).
- **Skill - Steel Cable:** Fires grappling wire to sling around platforms at extreme velocities.
- **Ultimate - Shadowburst Matrix:** Throws 5 zero-G plasma daggers and blinks through enemies upon recall.

### 3. 🎯 Artemis-9 (Marksman) — *Inspired by Layla & Granger*
- **Role:** Long-range siege artillery & recoil kiter (HP: 1,500 | Mass: 70 kg)
- **Passive - Gunner Recoil:** Railgun discharges generate massive reverse momentum ($-\vec{P}$).
- **Skill - Retro-Burst & Mines:** Directional thruster burst dropping 3 proximity flak mines.
- **Ultimate - Destruction Cannon:** Massive screen-spanning laser beam piercing all barriers and cores.

### 4. 🔮 Orion (Mage) — *Inspired by Eudora & Cyclops*
- **Role:** Spatial control & lockdown (HP: 1,750 | Mass: 75 kg)
- **Passive - Planetary Gravitation:** Orbiting celestial spheres shielding and auto-targeting nearby foes.
- **Skill - Stasis Orb:** Freezes enemy velocity to 0 and disables weapons for 1.8 seconds.
- **Ultimate - Event Horizon:** Micro-black-hole creating intense radial gravity suction before collapsing in a supernova.

### 5. ⏳ Chronia (Support) — *Inspired by Estes & Angela*
- **Role:** Causality preservation & clone survivability (HP: 1,800 | Mass: 68 kg)
- **Passive - Causality Resonance:** Aura regenerating health and boosting speed of all past friendly clones.
- **Skill - Temporal Barrier:** Casts protective chronal shield preventing paradox death.
- **Ultimate - Timeline Paradox Weave:** Supercharges attack speeds and permanently buffs clone lifespan.

---

## 🏗️ Architecture & Technical Features

- **Standalone Executable (`game.exe`):** Native Windows launcher compiled with .NET `csc.exe`, starting an embedded local HTTP server and launching an isolated borderless desktop app window.
- **Deterministic 60Hz Physics Engine (`src/engine/physics.js`):** Fixed-timestep Verlet integration, Newtonian recoil momentum, gravity wells, and elastic bounce bumpers ($1.35\times$ kinetic multiplier).
- **Time-Loop Input Stream Recorder (`src/engine/chrono.js`):** 60Hz input frame serialization, multi-clone playback manager, and telemetry drift reconciliation.
- **Procedural WebAudio Synthesizer (`src/engine/audio.js`):** Built-in zero-G sound synthesizer (filtered suit thrusters, railgun thumps, stasis pings, and rewind sweeps) requiring 0 external sound files.
- **Cyberpunk Particle VFX (`src/engine/particles.js`):** Dynamic thruster plumes, laser beams, black hole distortion shaders, and clone chromatic trails.

---

## 🚀 How to Run

### Method 1: Run the Standalone Game Executable (Easiest)
Simply double-click **`game.exe`** in this folder!

### Method 2: Open Directly in Web Browser
Open **`index.html`** in Google Chrome, Microsoft Edge, Firefox, or Safari.

### Method 3: Using Node / NPM
```bash
npm start
```
Or to recompile `game.exe`:
```bash
npm run build:exe
```

---

## 📜 Credits & Author
- **Author:** Charlie Mulya Putra
- **Class:** Kelas 12 (Project Game Canvas)
- **Repository:** [freerobuxreal303-cmyk/coolgame](https://github.com/freerobuxreal303-cmyk/coolgame.git)
- **License:** MIT License
